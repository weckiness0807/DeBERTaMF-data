Amazon data files orignially come from Julian McAuley's work.

If you want to get orignal data files, please visit to http://jmcauley.ucsd.edu/data/amazon/ and request them.

1. Amazon_Instant_Video_items.txt
   item ID::review1|review2|review3|...

2. Amazon_Instant_Video_ratings.txt (rating range: 1.0 to 5.0)
   user ID::item ID::ratings
